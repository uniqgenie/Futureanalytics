import StandardComingSoon from "@/components/StandardComingSoon/StandardComingSoon";
import ComingSoonVersion1 from "@/components/ComingSoonVersion1/ComingSoonVersion1";

export default function Home() {  
  return (    
      <>       
        {/* Standard Version */}
        <StandardComingSoon />
      </>
  );
}
