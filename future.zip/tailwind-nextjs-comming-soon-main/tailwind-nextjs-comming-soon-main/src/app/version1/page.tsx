import React from 'react'
import ComingSoonVersion1 from '@/components/ComingSoonVersion1/ComingSoonVersion1'

function Version1 () {
  return (
    <>
        <ComingSoonVersion1 />
    </>
  )
}

export default Version1